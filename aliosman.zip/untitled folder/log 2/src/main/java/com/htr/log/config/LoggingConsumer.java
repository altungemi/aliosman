package com.htr.log.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.htr.log.DTO.LogMessage;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class LoggingConsumer {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)
    public void receiveLogMessage(String messageAsJson) {
        try {
            LogMessage logMessage = objectMapper.readValue(messageAsJson, LogMessage.class);

            // Gelen logu konsola güzel bir formatta basalım
            System.out.printf("[%s] [%s] [%s] - %s%n",
                    logMessage.getTimestamp(),
                    logMessage.getServiceName(),
                    logMessage.getLevel(),
                    logMessage.getMessage()
            );
        } catch (Exception e) {
            System.err.println("Gelen log mesajı parse edilemedi: " + messageAsJson);
            e.printStackTrace();
        }
    }
}