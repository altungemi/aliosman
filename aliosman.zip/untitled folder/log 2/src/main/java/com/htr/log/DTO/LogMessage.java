package com.htr.log.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
public class LogMessage {
    private String timestamp;
    private String serviceName;
    private String level;
    private String threadName;
    private String loggerName;
    private String message;
    private String exception;
    private String traceId;
}